package spring;

public class MemberNotFoundException extends RuntimeException {
	private static final long serialVersionUID = 1541090213737607357L;
}
