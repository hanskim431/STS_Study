package spring;

public class WrongIdPasswordException extends RuntimeException {
	private static final long serialVersionUID = 5898894190296828306L;
}
